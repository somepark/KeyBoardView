//
//  main.m
//  KeyBoardViewDemo
//
//  Created by 牟元刚 on 2017/7/28.
//  Copyright © 2017年 somepark. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
