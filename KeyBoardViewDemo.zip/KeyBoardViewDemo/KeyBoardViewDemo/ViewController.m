//
//  ViewController.m
//  KeyBoardViewDemo
//
//  Created by 牟元刚 on 2017/7/28.
//  Copyright © 2017年 somepark. All rights reserved.
//

#import "ViewController.h"
#import "CustomKeyboard.h"
@interface ViewController ()
@property (nonatomic,strong)UITextField *textfield1;
@property (nonatomic,strong)UITextField *textfield2;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
    UITextField *t = [[UITextField alloc]initWithFrame:CGRectMake(20, 200, self.view.frame.size.width-40, 30)];
    t.backgroundColor = [UIColor orangeColor];
    [self.view addSubview:t];
    
    [[CustomKeyboardView manage]customKeyView:t keyboardType:CustomKeyboardTypeNumber|CustomKeyboardTypeLetter random:YES title:@"安全键盘1" length:6];
    _textfield1 = t;
    _textfield1.placeholder = @"请输入";
    
    UITextField *t1 = [[UITextField alloc]initWithFrame:CGRectMake(20, 250, self.view.frame.size.width-40, 30)];
    t1.backgroundColor = [UIColor orangeColor];
    [self.view addSubview:t1];
    [[CustomKeyboardView manage]customKeyView:t1 keyboardType:CustomKeyboardTypeNumber|CustomKeyboardTypeLetter random:YES title:@"安全键盘2"];
    _textfield2 = t1;
    _textfield2.placeholder = @"请输入";
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 300, CGRectGetWidth(self.view.frame), 100)];
    [self.view addSubview:btn];
    [self.inputView addSubview:btn];
    btn.center = CGPointMake(CGRectGetWidth(self.view.frame)/2,CGRectGetHeight(self.view.frame)/2);
    [btn setBackgroundColor:[UIColor lightGrayColor]];
    [btn addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)action:(UIButton *)btn{
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    btn.titleLabel.numberOfLines = 0;
    [btn setTitle:[NSString stringWithFormat:@"textField1=%@,,,,textField2=%@",_textfield1.secureText,_textfield2.secureText] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
