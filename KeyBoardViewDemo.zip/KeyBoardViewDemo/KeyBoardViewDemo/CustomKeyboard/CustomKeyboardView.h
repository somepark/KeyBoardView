//
//  CustomKeyboardView.h
//  SwPractice
//
//  Created by bamq on 2017/5/31.
//  Copyright © 2017年 Aresoft (Shanghai) Tech Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomInputAccessoryView.h"
@interface CustomKeyboardView : UIView<UIInputViewAudioFeedback>
+(instancetype)manage;
-(void)customKeyView:(UIView<UIKeyInput> *)view keyboardType:(CustomKeyboardType)keyboardType random:(BOOL)random title:(NSString *)title;
-(void)customKeyView:(UIView<UIKeyInput> *)view keyboardType:(CustomKeyboardType)keyboardType random:(BOOL)random title:(NSString *)title length:(NSInteger)length;
@end
