//
//  KeyboardCollectionViewCell.h
//  SwPractice
//
//  Created by bamq on 2017/5/31.
//  Copyright © 2017年 Aresoft (Shanghai) Tech Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyboardCollectionViewCell:UICollectionViewCell
@property(nonatomic,strong)UILabel *textLabel;
@property(nonatomic,strong)UIImageView *imageView;
@end
