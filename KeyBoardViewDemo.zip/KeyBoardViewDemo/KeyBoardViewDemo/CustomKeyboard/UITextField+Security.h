//
//  UITextField+Security.h
//  SwPractice
//
//  Created by bamq on 2017/5/31.
//  Copyright © 2017年 Aresoft (Shanghai) Tech Co.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Security)
@property(nonatomic,strong)NSString *secureText;
@end
